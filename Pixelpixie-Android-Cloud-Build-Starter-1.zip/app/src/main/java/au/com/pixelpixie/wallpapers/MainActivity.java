package au.com.pixelpixie.wallpapers;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> upload;
 @Override public void onCreate(Bundle b) { super.onCreate(b); web=new WebView(this); setContentView(web);
  web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true); web.setWebViewClient(new WebViewClient());
  web.setWebChromeClient(new WebChromeClient(){ @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams params){ upload=cb; try { startActivityForResult(params.createIntent(), 42); return true; } catch(Exception e){upload=null;return false;} }});
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==42 && upload!=null){upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res,data));upload=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
